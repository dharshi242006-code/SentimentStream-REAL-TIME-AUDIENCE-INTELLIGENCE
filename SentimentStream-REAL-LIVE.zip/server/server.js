require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const mongoose = require('mongoose');
const { Server } = require('socket.io');
const stream = require('./services/stream');
const Reading = require('./models/Reading');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/sentimentstream';
const PORT = process.env.PORT || 3000;

const app = express();
app.use(cors(), express.json());
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// Start tracking a topic. body: { topic: "Leo", mode: "mock" | "live" }
app.post('/api/track', async (req, res) => {
  const { topic, mode } = req.body;
  if (!topic) return res.status(400).json({ error: 'topic required' });
  try {
    if (mode === 'live') await stream.startLive(topic, io);
    else stream.startMock(topic, io);
    res.json({ ok: true, topic, mode: mode || 'mock', live: mode === 'live' });
  } catch (e) {
    res.status(502).json({ error: e.message || 'Live source connection failed' });
  }
});

app.get('/api/live-status', (req, res) => res.json(stream.liveStatus()));

app.post('/api/stop', (req, res) => { stream.stop(); res.json({ ok: true }); });

// Historical averages straight from MongoDB
app.get('/api/history/:topic', async (req, res) => {
  const data = await Reading.aggregate([
    { $match: { 'meta.topic': req.params.topic } },
    { $group: { _id: '$label', count: { $sum: 1 }, avgScore: { $avg: '$score' } } }
  ]);
  res.json(data);
});

mongoose.connect(MONGO_URI)
  .then(() => {
    console.log('MongoDB connected');
    server.listen(PORT, () => console.log(`API running on http://localhost:${PORT}`));
  })
  .catch(err => { console.error('MongoDB connection failed:', err.message); process.exit(1); });
