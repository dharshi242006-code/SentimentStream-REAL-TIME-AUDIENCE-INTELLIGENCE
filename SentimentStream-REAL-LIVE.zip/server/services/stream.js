const Sentiment = require('sentiment');
const sentiment = new Sentiment();
const Reading = require('../models/Reading');

const templates = [
  'I absolutely love {t}, it is amazing!',
  '{t} is terrible, total waste of time',
  'Just saw {t} today, it was okay',
  'Honestly {t} exceeded my expectations',
  '{t} keeps crashing, so disappointing',
  'Heard about {t}, not sure what to think',
  'Best thing ever: {t}!',
  'I hate how {t} handled this',
  'Great work by the {t} team, really impressive',
  'Worst experience with {t}, never again'
];

let timer = null;
let state = { mode: null, topic: '', connected: false, lastError: '', lastPoll: null, received: 0 };

function score(text) {
  const s = sentiment.analyze(text).score;
  return { score: s, label: s > 0 ? 'positive' : s < 0 ? 'negative' : 'neutral' };
}

function startMock(topic, io) {
  stop();
  state = { mode: 'mock', topic, connected: true, lastError: '', lastPoll: new Date(), received: 0 };
  io.emit('stream-status', state);
  timer = setInterval(async () => {
    const text = templates[Math.floor(Math.random() * templates.length)].replace('{t}', topic);
    const doc = { timestamp: new Date(), meta: { topic }, text, ...score(text) };
    try { await Reading.create(doc); } catch (e) { console.error('DB error:', e.message); }
    state.received++;
    io.emit('reading', doc);
  }, 1000);
}

let redditToken = null;
let redditTokenExpiresAt = 0;

async function getRedditToken() {
  const id = process.env.REDDIT_CLIENT_ID;
  const secret = process.env.REDDIT_CLIENT_SECRET;
  if (!id || !secret || id.startsWith('YOUR_') || secret.startsWith('YOUR_')) {
    throw new Error('Reddit API credentials are missing. Add REDDIT_CLIENT_ID and REDDIT_CLIENT_SECRET to server/.env.');
  }
  if (redditToken && Date.now() < redditTokenExpiresAt - 60000) return redditToken;

  const basic = Buffer.from(`${id}:${secret}`).toString('base64');
  const response = await fetch('https://www.reddit.com/api/v1/access_token', {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${basic}`,
      'Content-Type': 'application/x-www-form-urlencoded',
      'User-Agent': process.env.REDDIT_USER_AGENT || 'SentimentStream/1.0'
    },
    body: new URLSearchParams({ grant_type: 'client_credentials' })
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok || !body.access_token) throw new Error(`Reddit authentication failed (${response.status}). ${body.message || body.error || 'Check your Reddit app credentials.'}`);
  redditToken = body.access_token;
  redditTokenExpiresAt = Date.now() + Number(body.expires_in || 3600) * 1000;
  return redditToken;
}

async function fetchReddit(topic) {
  const token = await getRedditToken();
  const url = new URL('https://oauth.reddit.com/search.json');
  url.searchParams.set('q', topic);
  url.searchParams.set('sort', 'new');
  url.searchParams.set('limit', '50');
  url.searchParams.set('t', 'day');
  url.searchParams.set('raw_json', '1');
  const response = await fetch(url, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'User-Agent': process.env.REDDIT_USER_AGENT || 'SentimentStream/1.0'
    }
  });
  if (response.status === 401) { redditToken = null; redditTokenExpiresAt = 0; throw new Error('Reddit access token expired or was rejected. Restart the stream to refresh it.'); }
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(`Reddit live request failed (${response.status}). ${body.message || body.error || 'Try again shortly.'}`);
  return body?.data?.children || [];
}

async function startLive(topic, io) {
  stop();
  const seen = new Set();
  const queue = [];
  const pollMs = Math.max(10000, Number(process.env.REDDIT_POLL_MS || 15000));
  state = { mode: 'live', topic, connected: false, lastError: '', lastPoll: null, received: 0 };
  io.emit('stream-status', state);

  const poll = async () => {
    try {
      const children = await fetchReddit(topic);
      let fresh = 0;
      for (const c of children) {
        const d = c.data || {};
        if (!d.id || seen.has(d.id)) continue;
        seen.add(d.id);
        const text = [d.title, d.selftext].filter(Boolean).join(' — ').trim();
        if (text) { queue.push({ id: d.id, text, url: d.permalink ? `https://www.reddit.com${d.permalink}` : null, subreddit: d.subreddit || null }); fresh++; }
      }
      if (seen.size > 5000) { const first = seen.values().next().value; seen.delete(first); }
      state = { ...state, connected: true, lastError: '', lastPoll: new Date(), queued: queue.length };
      io.emit('stream-status', state);
      if (fresh) io.emit('live-batch', { count: fresh });
    } catch (e) {
      state = { ...state, connected: false, lastError: e.message, lastPoll: new Date() };
      io.emit('stream-status', state);
      console.error('Reddit live poll failed:', e.message);
    }
  };

  await poll();
  const pollTimer = setInterval(poll, pollMs);
  const emitTimer = setInterval(async () => {
    const item = queue.shift();
    if (!item) return;
    const doc = { timestamp: new Date(), meta: { topic, source: 'reddit', sourceId: item.id, subreddit: item.subreddit, url: item.url }, text: item.text, ...score(item.text) };
    try { await Reading.create(doc); } catch (e) { console.error('DB error:', e.message); }
    state.received++;
    state.queued = queue.length;
    io.emit('reading', doc);
    io.emit('stream-status', state);
  }, 750);
  timer = { clear: () => { clearInterval(pollTimer); clearInterval(emitTimer); } };
}

function stop() {
  if (timer) { if (timer.clear) timer.clear(); else clearInterval(timer); }
  timer = null;
  state = { ...state, mode: null, connected: false };
}

function liveStatus() { return state; }

module.exports = { startMock, startLive, stop, liveStatus };
