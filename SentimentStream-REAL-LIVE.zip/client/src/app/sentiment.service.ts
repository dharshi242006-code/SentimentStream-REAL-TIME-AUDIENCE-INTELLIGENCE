import { Injectable } from '@angular/core';
import { io } from 'socket.io-client';
import { Subject } from 'rxjs';

export interface Reading {
  timestamp: string;
  text: string;
  score: number;
  label: 'positive' | 'negative' | 'neutral';
}

const API = 'http://localhost:3000';

@Injectable({ providedIn: 'root' })
export class SentimentService {
  private socket = io(API);
  reading$ = new Subject<Reading>();
  status$ = new Subject<any>();

  constructor() {
    this.socket.on('reading', (r: Reading) => this.reading$.next(r));
    this.socket.on('stream-status', (s: any) => this.status$.next(s));
  }

  async track(topic: string, mode: 'mock' | 'live') {
    const response = await fetch(`${API}/api/track`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ topic, mode })
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.error || `Unable to start ${mode} stream`);
    return body;
  }

  async stop() {
    await fetch(`${API}/api/stop`, { method: 'POST' });
  }

  async history(topic: string) {
    const res = await fetch(`${API}/api/history/${encodeURIComponent(topic)}`);
    return res.json();
  }
}
