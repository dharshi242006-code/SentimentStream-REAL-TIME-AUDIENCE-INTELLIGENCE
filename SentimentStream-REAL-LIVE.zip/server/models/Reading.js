const mongoose = require('mongoose');

// MongoDB Time Series collection (needs MongoDB 5.0+)
const schema = new mongoose.Schema(
  {
    timestamp: { type: Date, required: true },
    meta: { topic: String },
    text: String,
    score: Number,
    label: String // positive | negative | neutral
  },
  { timeseries: { timeField: 'timestamp', metaField: 'meta', granularity: 'seconds' } }
);

module.exports = mongoose.model('Reading', schema);
