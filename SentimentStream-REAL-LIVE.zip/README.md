# SentimentStream — Real Live Reddit Sentiment Intelligence

This version uses the **real Reddit Data API**, not generated/demo comments. Reddit posts matching the tracked topic are polled, deduplicated, scored, stored in MongoDB, and pushed to Angular through Socket.IO. Reddit documents OAuth/API access and search/listing endpoints in its developer API documentation.

## 1. Install

### Backend
```powershell
cd server
npm install
```

### Frontend
```powershell
cd client
npm install
```

## 2. Configure Reddit API

Create/register a Reddit developer application and obtain its client ID and secret. Reddit currently requires developers using the Data API to register their apps; see the official developer registration page: https://developers.reddit.com/app-registration

Copy `server/.env.example` to `server/.env` and fill in:

```env
MONGO_URI=mongodb://127.0.0.1:27017/sentimentstream
PORT=3000
REDDIT_CLIENT_ID=your_client_id
REDDIT_CLIENT_SECRET=your_client_secret
REDDIT_USER_AGENT=SentimentStream/1.0 by u/your_reddit_username
REDDIT_POLL_MS=15000
```

**Never put the Reddit secret in Angular/client code or commit `.env` to GitHub.**

## 3. Start

Terminal 1:
```powershell
cd server
npm start
```

Terminal 2:
```powershell
cd client
npm start
```

Open `http://localhost:4200`.

## 4. Start a real stream

1. Choose `Reddit Live (REAL)`.
2. Enter a topic such as `iPhone 17`, `Netflix`, `Tesla`, or a movie name.
3. Click **Start Tracking**.
4. The server obtains a Reddit OAuth token, searches new matching posts, removes duplicates, performs sentiment analysis, saves each reading to MongoDB, and sends each reading to the browser over Socket.IO.
5. The dashboard shows a **REDDIT API CONNECTED** status when polling succeeds.

## 5. If the live source fails

The dashboard now shows the actual Reddit/API error instead of silently displaying an empty feed. Check the backend terminal as well. Common causes are missing/invalid Reddit credentials, an unregistered/disabled API application, network access, or Reddit API rate/access restrictions.

This project deliberately does **not** fabricate fallback readings in `live` mode.
