import { Component, AfterViewInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Chart, registerables } from 'chart.js';
import { Subscription } from 'rxjs';
import { SentimentService, Reading } from './sentiment.service';

Chart.register(...registerables);

type Counts = { positive: number; negative: number; neutral: number };

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements AfterViewInit, OnDestroy {
  topic = '';
  mode: 'mock' | 'live' = 'mock';
  running = false;
  currentTopic = '';
  feed: Reading[] = [];
  counts: Counts = { positive: 0, negative: 0, neutral: 0 };
  total = 0;
  avg = 0;
  history: any[] = [];
  alertEnabled = true;
  alertThreshold = 30;
  alertMessage = '';
  showAll = false;
  darkMode = true;
  selectedPreset = '';
  lastUpdated = '';
  streamStatus: any = { connected: false, lastError: '' };
  streamError = '';
  private line!: Chart;
  private pie!: Chart;
  private sub?: Subscription;
  private sum = 0;
  private scores: number[] = [];

  readonly presets = [
    { name: 'iPhone', icon: '📱' }, { name: 'Netflix', icon: '🎬' },
    { name: 'Tesla', icon: '⚡' }, { name: 'OnePlus', icon: '🚀' },
    { name: 'New Movie', icon: '🍿' }, { name: 'Food Delivery', icon: '🍔' }
  ];

  constructor(private svc: SentimentService) {}

  ngAfterViewInit() {
    this.line = new Chart('lineChart', {
      type: 'line', data: { labels: [], datasets: [{ label: 'Live sentiment score', data: [], borderColor: '#8b7cff', backgroundColor: 'rgba(139,124,255,.12)', fill: true, tension: .4, pointRadius: 2, pointHoverRadius: 5 }] },
      options: { responsive: true, maintainAspectRatio: false, animation: { duration: 250 }, plugins: { legend: { display: false } }, scales: { x: { grid: { display: false }, ticks: { color: '#7f8aa3', maxTicksLimit: 8 } }, y: { min: -6, max: 6, grid: { color: 'rgba(255,255,255,.06)' }, ticks: { color: '#7f8aa3' } } } }
    });
    this.pie = new Chart('pieChart', {
      type: 'doughnut', data: { labels: ['Positive', 'Negative', 'Neutral'], datasets: [{ data: [0,0,0], backgroundColor: ['#32d583','#ff5c75','#8b95aa'], borderWidth: 0, hoverOffset: 6 }] },
      options: { responsive: true, maintainAspectRatio: false, cutout: '72%', plugins: { legend: { position: 'bottom', labels: { color: '#b8c0d4', usePointStyle: true, padding: 18 } } } }
    });
    this.sub = this.svc.reading$.subscribe(r => this.onReading(r));
    this.svc.status$.subscribe(s => { this.streamStatus = s; if (s?.lastError) this.streamError = s.lastError; else if (s?.connected) this.streamError = ''; });
  }

  choosePreset(name: string) { this.selectedPreset = name; this.topic = name; }

  private onReading(r: Reading) {
    this.counts[r.label]++; this.total++; this.sum += r.score; this.avg = +(this.sum / this.total).toFixed(2);
    this.scores.push(r.score); if (this.scores.length > 40) this.scores.shift();
    this.feed = [r, ...this.feed].slice(0, 20); this.lastUpdated = new Date().toLocaleTimeString();
    const labels = this.line.data.labels as string[]; const data = this.line.data.datasets[0].data as number[];
    labels.push(new Date(r.timestamp).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit', second:'2-digit'})); data.push(r.score);
    if (labels.length > 35) { labels.shift(); data.shift(); } this.line.update('none');
    this.pie.data.datasets[0].data = [this.counts.positive, this.counts.negative, this.counts.neutral]; this.pie.update('none');
    this.checkAlert();
  }

  checkAlert() {
    const negativeRate = this.total ? this.counts.negative / this.total * 100 : 0;
    if (this.alertEnabled && negativeRate >= this.alertThreshold) this.alertMessage = `⚠ Negative sentiment reached ${negativeRate.toFixed(0)}% — attention recommended.`;
    else this.alertMessage = '';
  }

  private reset() {
    this.counts = {positive:0, negative:0, neutral:0}; this.total=0; this.sum=0; this.avg=0; this.feed=[]; this.history=[]; this.scores=[]; this.alertMessage=''; this.lastUpdated='';
    (this.line.data.labels as string[]).length=0; (this.line.data.datasets[0].data as number[]).length=0; this.line.update('none');
    this.pie.data.datasets[0].data=[0,0,0]; this.pie.update('none');
  }

  async start() { const t=this.topic.trim(); if(!t)return; this.reset(); this.currentTopic=t; this.streamError=''; try { await this.svc.track(t,this.mode); this.running=true; } catch (e:any) { this.running=false; this.streamError=e?.message || 'Unable to start live stream'; } }
  async stop() { await this.svc.stop(); this.running=false; this.streamStatus={...this.streamStatus,connected:false}; this.history=await this.svc.history(this.currentTopic); }
  async loadHistory() { if(this.currentTopic) this.history=await this.svc.history(this.currentTopic); }

  get positiveRate() { return this.total ? Math.round(this.counts.positive/this.total*100) : 0; }
  get negativeRate() { return this.total ? Math.round(this.counts.negative/this.total*100) : 0; }
  get neutralRate() { return this.total ? Math.round(this.counts.neutral/this.total*100) : 0; }
  get mood() { if(!this.total) return 'Waiting'; if(this.positiveRate>=60) return 'Loved'; if(this.negativeRate>=45) return 'At Risk'; return 'Mixed'; }
  get moodEmoji() { return this.mood==='Loved'?'🔥':this.mood==='At Risk'?'🚨':this.mood==='Mixed'?'⚡':'✨'; }
  get trend() { if(this.scores.length<4) return 'Collecting signal'; const n=this.scores.length; const a=this.scores.slice(n-4).reduce((x,y)=>x+y,0)/4; const b=this.scores.slice(Math.max(0,n-8),n-4).reduce((x,y)=>x+y,0)/Math.min(4,n-4); return a>b+.2?'Rising ↑':a<b-.2?'Falling ↓':'Stable →'; }
  get insight() { if(!this.total) return 'Start a stream to generate live audience intelligence.'; if(this.positiveRate>=65) return `${this.currentTopic} is resonating strongly. Positive reactions are dominating the live stream.`; if(this.negativeRate>=45) return `Audience friction is visible. Review the newest negative reactions and identify recurring issues.`; return `Reactions are mixed. Watch the trend line and incoming feed for the next signal shift.`; }
  get visibleFeed() { return this.showAll ? this.feed : this.feed.slice(0,8); }

  exportCsv() {
    const rows=[['Time','Topic','Sentiment','Score','Text'],...this.feed.map(r=>[new Date(r.timestamp).toISOString(),this.currentTopic,r.label,r.score,`"${r.text.replaceAll('"','""')}"`])];
    const blob=new Blob([rows.map(x=>x.join(',')).join('\n')],{type:'text/csv'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=`sentimentstream-${this.currentTopic || 'report'}.csv`; a.click(); URL.revokeObjectURL(a.href);
  }

  toggleTheme() { this.darkMode=!this.darkMode; document.body.classList.toggle('light-mode', !this.darkMode); }
  ngOnDestroy(){this.sub?.unsubscribe();}
}
